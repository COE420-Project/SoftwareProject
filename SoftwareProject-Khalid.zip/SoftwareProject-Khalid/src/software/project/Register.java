package software.project;

import java.awt.*; 
import javax.swing.*;
public class Register extends javax.swing.JFrame{

String email;
String Password;





String HashPassword(String password ) {
	
	return password;// to be implemented 
}

void RegisterToDb(String email, String Password ) {
	
}




}
